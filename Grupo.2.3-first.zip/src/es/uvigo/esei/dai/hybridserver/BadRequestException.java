package es.uvigo.esei.dai.hybridserver;

public class BadRequestException extends Exception {



	/**
	 * 
	 */
	private static final long serialVersionUID = -6795701396094000379L;

	public  BadRequestException(String err) {
		super(err);
		
	}
	
	
}
